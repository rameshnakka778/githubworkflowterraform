from dotenv import load_dotenv
from retl_component import glue_secret
import os
load_dotenv()

ENVIRONMENT = (os.getenv('ENVIRONMENT', 'prod'))
if ENVIRONMENT.lower() == 'local':
    DB_CREDENTIALS = {
        "host": os.getenv('HOST'),
        "port": os.getenv('PORT'),
        "sid": os.getenv('SID'),
        "user": os.getenv('USER'),
        "password": os.getenv('PASSWORD'),
    }
    print("DB_CREDENTIALS:", DB_CREDENTIALS)

else:
    DB_CREDENTIALS = glue_secret.get_secret()

