from config.load_configurations import load_configuration
from config.constants import *
from retl_component import common_module

REQUIRED_JOB_PARAM = CONST_SCRIPT_REQUIRED_PARAMS
ENVIRONMENT = CONST_ENVIRONMENT

"""
Assuming AWS account/bucket_name/file_path could be changed
but filename remain same in any account
"""

DWI_CONFIG_FILENAME = CONST_DWI_CONFIG_FILENAME
PRE_DWI_EXTRACT_FILENAME = CONST_PRE_DWI_EXTRACT_FILENAME

JOB_PARAMS = common_module.get_job_params(REQUIRED_JOB_PARAM, optional_params=CONST_OPTIONAL_PARAMS)

if ENVIRONMENT.lower() == 'local':
    DWI_CONFIG = CONST_LOCAL_CONFIG

else:
    DWI_CONFIG = load_configuration(job_params=JOB_PARAMS,
                                    dwi_config_filename=DWI_CONFIG_FILENAME,
                                    pre_dwi_extract=PRE_DWI_EXTRACT_FILENAME)

# =================DWI Configurations======================

DBNAME = DWI_CONFIG['dbname']
RMS_OWNER = DWI_CONFIG['rms_owner']
BA_OWNER = DWI_CONFIG['ba_owner']
# START_INS_PD1071
TUPRM_OWNER = DWI_CONFIG['tuprm_owner']
"""
valid values for LANGUAGE are: en, fr, ja, es
en = english, fr = french, ja = japanese, es = spanish
"""
LANGUAGE = DWI_CONFIG['language']
"""
Valid values for LOAD_TYPE are: conventional, direct
"""
LOAD_TYPE = DWI_CONFIG['load_type']
RETL_MAX_HEAP_SIZE = DWI_CONFIG['retl_max_heap_size']
ISCL_PROCESS = DWI_CONFIG['iscl_process']
ISC_PROCESS = DWI_CONFIG['isc_process']
IM_PROCESS = DWI_CONFIG['im_process']
NVL = DWI_CONFIG['nvl']
DB_ENV = DWI_CONFIG["db_env"]
NLS_NUMERIC_CHARACTERS = ".,"

# Changeable File data
# odate is equal to vdate
ODATE = DWI_CONFIG['vdate']  # not found in dwi_extrcat
VDATE = DWI_CONFIG['vdate']
PRIME_CURRENCY_CODE = DWI_CONFIG['prime_currency_code']
CONSOLIDATION_CODE = DWI_CONFIG["consolidation_code"]
NEXT_VDATE = DWI_CONFIG["next_vdate"]
VAT_IND = DWI_CONFIG["vat_ind"]
CLASS_LEVEL_VAT_IND = DWI_CONFIG["class_level_vat_ind"]
DOMAIN_LEVEL = DWI_CONFIG["domain_level"]
STKLDGR_VAT_INCL_RETL_IND = DWI_CONFIG["stkldgr_vat_incl_retl_ind"]
MULTI_CURRENCY_IND = DWI_CONFIG["multi_currency_ind"]
PRIME_EXCHNG_RATE = DWI_CONFIG["prime_exchng_rate"]
LAST_EOW_DATE = DWI_CONFIG['last_eow_date']
LAST_EOM_DATE = DWI_CONFIG['last_eom_date']
CURR_BOM_DATE = DWI_CONFIG['curr_bom_date']
MAX_BACKPOST_DAYS = DWI_CONFIG['max_backpost_days']

CONVERT_VDATE = f"TO_DATE('{VDATE}','YYYYMMDD')"
CONVERT_LAST_EOM_DATE = f"TO_DATE('{DWI_CONFIG['last_eom_date']}','YYYYMMDD')"
CONVERT_CURR_BOM_DATE = f"TO_DATE('{DWI_CONFIG['curr_bom_date']}','YYYYMMDD')"
CONVERT_LAST_EOW_DATE = f"TO_DATE('{DWI_CONFIG['last_eow_date']}','YYYYMMDD')"

if __name__ == "__main__":
    print("======")
