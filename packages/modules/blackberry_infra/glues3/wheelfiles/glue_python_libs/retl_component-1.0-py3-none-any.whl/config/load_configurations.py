from retl_component.aws_s3_service import S3
import json

def load_configuration(**configs):
    """
    This function is used to load configuration from s3 bucket.
    1. It loads dwi_configuration from s3 bucket that is in json format
    2. it reads date files(changeable dates)
    like odate, vdate,that every day gets updated.
    This function club dwi_configuration +
     changeable dates and return dictionary

    **configs:
        job_params
        dwi_config_filename
        pre_dwi_extract


    :param configs:
    :return:
    """

    print("Reading Configuration from S3.....")
    job_params = configs['job_params']
    dwi_config_filename = configs['dwi_config_filename']
    pre_dwi_extract = configs['pre_dwi_extract']
    # dynamic_files = configs['dynamic_files']

    bucket_name = job_params['config_bucket_name']
    file_path = job_params['config_file_path']
    obj = S3(bucket_name=bucket_name)
    dwi_config = obj.read_file_contents(s3_file_path=file_path,
                                        s3_filename=dwi_config_filename)
    dwi_config = json.loads(dwi_config)

    pre_dwi_extract_data = obj.read_file_contents(s3_file_path=file_path,
                                        s3_filename=pre_dwi_extract)
    dwi_extract_data = json.loads(pre_dwi_extract_data)


    dwi_config.update(dwi_extract_data)
    return dwi_config


if __name__ == "__main__":
    pass
