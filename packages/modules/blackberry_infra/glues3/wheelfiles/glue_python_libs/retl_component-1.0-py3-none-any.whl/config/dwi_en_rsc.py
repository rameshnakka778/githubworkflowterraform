"""
########################################################
# Copyright (c) 2002, Retek Inc.  All rights reserved.
# $Workfile:   $   dwi_en.rsc
# $Revision:   $
# $Modtime:    $
########################################################

##########################################################
# Resource File which contains hard coded english strings 
# that will be used by extraction and load programs.
##########################################################
"""

# orglocex.ksh #
# LOC_TYPE_DESC1 = "Store"
# LOC_TYPE_DESC2 = "Warehouse"

# # prddepex.ksh #
# PURCHASE_TYPE1="Normal Merchandise"
# PURCHASE_TYPE2="Consignment Stock"
# MARKUP_CALC_TYPE1="Retail"
# MARKUP_CALC_TYPE2="Cost"
#
# # prditmex.ksh #
# PACK_SELLABLE_DESC1="Sellable Pack"
# PACK_SELLABLE_DESC2="Non-Sellable Pack"
# PACK_SIMPLE_DESC1="Simple Pack"
# PACK_SIMPLE_DESC2="Complex Pack"
# PACK_ORDERABLE_DESC1="Vendor Orderable Pack"
# PACK_ORDERABLE_DESC2="Buyer Orderable Pack"
# PACK_ORDERABLE_DESC3="Non-Orderable Pack"
# PACK_NOT_DESC1="Not a Pack"
#
# # prmschex.ksh #
# SCHM_TYPE_DESC1="Mix Match"
# SCHM_TYPE_DESC2="Threshold"
# SCHM_TYPE_DESC3="Cheapest Free"
# SCHM_TYPE_DESC4="Multi Deal"
#
# # rsnex.ksh #
# REASN_TYPE_DESC1="Stock Adjustment"
# REASN_TYPE_DESC2="RTV from Inventory"
# REASN_TYPE_DESC3="Unavailable Inventory Transfer"
# REASN_TYPE_CLASS1="Inventory Adjustment"
# REASN_TYPE_CLASS2="Return to Vendor"
#
# # supctrex.ksh #
# STATUS_DESC1="Inserted Contract"
# STATUS_DESC2="Completed Contract"
# STATUS_DESC3="Closed Contract"
#
# # supsupex.ksh #
# SUP_ACTIVE="Active"
# SUP_INACTIVE="Inactive"
# SUP_DOMESTIC="Domestic"
# SUP_FOREIGN="Foreign"
#
# # extract_time.ksh #
# TIME_454_SQL="time_454.txt"
# WKDAY_SQL="wkday.txt"
