from dotenv import load_dotenv,dotenv_values
import os
load_dotenv()
"""
Assuming AWS account/bucket_name/file_path could be changed
but filename remain same in any account
"""
CONST_ENV_FILE = '../../.env'
CONST_DWI_CONFIG_FILENAME = "dwi_config.json"
CONST_PRE_DWI_EXTRACT_FILENAME = "pre_dwi_extract.json"
CONST_ORACLE_INSTANT_CLIENT_DIR = "instantclient_18_5"
CONST_ORACLE_CLIENT_LIB_PATH = "glue-python-libs"
# These parameters are required for almost all retl_script
CONST_SCRIPT_REQUIRED_PARAMS = ['bucket_name', 's3_file_path', 's3_filename',
                                'config_bucket_name', 'config_file_path']
CONST_OPTIONAL_PARAMS = ["reject_file_path", "reject_filename"]
# These parameters are required for config file
CONST_CONFIG_REQUIRED_PARAMS = ['config_bucket_name', 'config_file_path']
CONST_ORACLE_INSTANTCLIENT_PATH = os.getenv('ORACLE_INSTANTCLIENT_PATH', None)
CONST_ENVIRONMENT = (os.getenv('ENVIRONMENT', 'prod'))
CONST_LOCAL_CONFIG = dotenv_values(CONST_ENV_FILE)  # Get Environment variable in dictionary
