import zipfile
import os
import glob
import cx_Oracle
import shutil
import sqlalchemy
from sqlalchemy.exc import SQLAlchemyError
from config.constants import CONST_ORACLE_CLIENT_LIB_PATH,\
    CONST_ORACLE_INSTANT_CLIENT_DIR,CONST_ORACLE_INSTANTCLIENT_PATH

from config.database_config import ENVIRONMENT,DB_CREDENTIALS

glue_cwd = os.getcwd()  # get current working directory
INSTANTCLIENT = 'instantclient'

def extract_instant_client_files(file_prefix, to_glue_dir):

    cx_zip_dir = ''

    for name in glob.glob(f'./{CONST_ORACLE_CLIENT_LIB_PATH}*/{file_prefix}*',
                          recursive=True):
        cx_zip_dir = name
    print(f'Cx oracle zipped file directory: {cx_zip_dir}'
          f' and Instant Client folder: {CONST_ORACLE_INSTANT_CLIENT_DIR}')

    # extract files to current working directory
    with zipfile.ZipFile(cx_zip_dir, 'r') as f:
        f.extractall(to_glue_dir)

    # move extracted files to current working directory
    source = f'{to_glue_dir}/{CONST_ORACLE_INSTANT_CLIENT_DIR}/'
    destination = f'{to_glue_dir}/'
    for f in os.listdir(source):
        shutil.move(source + f, destination + f)

    # check if files exists in current dir--- To be coded
    return True


def initialise_oracle_client(lib_dir):
    try:
        # extract oracle client files to local
        status = extract_instant_client_files(
            INSTANTCLIENT, to_glue_dir=glue_cwd)

        if status:
            # initiate client libraries
            cx_Oracle.init_oracle_client(lib_dir=lib_dir)
            return True
        else:
            return False

    except Exception as e:
        print("Exception Occurred:", str(e))
        raise ValueError("Instance oracle client not set properly.")


if ENVIRONMENT.lower() == 'local':
    cx_Oracle.init_oracle_client(
        lib_dir=r"{path}".format(
            path=CONST_ORACLE_INSTANTCLIENT_PATH))
else:
    status = initialise_oracle_client(lib_dir=glue_cwd)
    if not status:
        print("Instance oracle client not set properly.")


class DBConnection:

    def __init__(self):
        self.connection = None
        self.cursor = None
        self.secret_credentials = DB_CREDENTIALS

    def get_connection(self):
        try:
            dsn = cx_Oracle.makedsn(host=self.secret_credentials['host'],
                                    port=self.secret_credentials['port'],
                                    sid=self.secret_credentials['sid'])
            self.connection = cx_Oracle.connect(
                self.secret_credentials['user'],
                self.secret_credentials['password'],
                dsn,
                encoding='UTF-8')
            return self.connection.cursor(), self.connection

        except Exception as e:
            raise e

    def connection_close(self):
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()


class SqlAlchmyEngine:

    def __init__(self):
        self.conn = None
        self.secret_credentials = DB_CREDENTIALS

    def get_oracle_engine(self, array_size=1000):

        try:
            dsn = cx_Oracle.makedsn(host=self.secret_credentials['host'],
                                    port=self.secret_credentials['port'],
                                    sid=self.secret_credentials['sid'])
            connection_url = f"oracle+cx_oracle://" \
                             f"{self.secret_credentials['user']}:" \
                             f"{self.secret_credentials['password']}@{dsn}"

            engine = sqlalchemy.create_engine(connection_url,
                                              arraysize=array_size)
            return engine
        except SQLAlchemyError as e:
            print("Exception")
            raise (e)

    def get_oracle_connection(self, array_size=1000):

        engine = self.get_oracle_engine(array_size=array_size)
        self.conn = engine.connect()
        return self.conn

    def close_oracle_connection(self):

        if self.conn:
            self.conn.close()

    @staticmethod
    def execute_query(connection, sql_query):
        results = connection.execute(sql_query)
        return results

    @staticmethod
    def drop_table(connection, table_name):
        drop_table_query = f"""BEGIN
                EXECUTE IMMEDIATE 'DROP TABLE {table_name}';
                EXCEPTION
                WHEN OTHERS THEN
                    IF SQLCODE != -942 THEN    
                    RAISE;
                END IF;
                END;"""

        connection.execute(drop_table_query)

    @staticmethod
    def analyze_table(connection, schema_owner, table_name):
        analyze_table_query = f"""
        BEGIN
           sys.dbms_stats.gather_table_stats('{schema_owner}','{table_name}');
        END;
        """
        connection.execute(analyze_table_query)


if __name__ == "__main__":
    ""
    pass
