import pandas as pd
from config.retl_config import BA_OWNER, MULTI_CURRENCY_IND, PRIME_EXCHNG_RATE


def currency_converter(input_dataset, idnt_type, convert_amt_fields, sql_engine, primary2local="",
                       prime_exchng_rate=float(PRIME_EXCHNG_RATE),
                       ba_owner=BA_OWNER, multi_currency_ind=MULTI_CURRENCY_IND):
    '''
    :param input_dataset: The dataframe that needs to be passed to the function
    :param ba_owner: The name of the ba owner
    :param idnt_type: the name of the identity type which is the name of the column from input_dataset
    :param convert_amt_fields: the list of the fields to be passed which needs to be converted
    :param multi_currency_ind: This should be passed by the user
    :param primary2local: This should be passed by the user
    :param prime_exchng_rate: This should be passed by the user
    :return: The transformed dataframe and the rejected file
    '''

    try:

        IDNT_TYPE_COLUMN = "{}_IDNT".format(idnt_type)

        if (idnt_type != "" and convert_amt_fields != []):

            if multi_currency_ind == "Y":

                sql_query1 = "SELECT {}, DAY_DT, LOCAL_EXCHNG_RATE FROM {}.{}_EXCHNG_RATE_TEMP".format(IDNT_TYPE_COLUMN,
                                                                                                       ba_owner,
                                                                                                       idnt_type)

                LOC_rate_temp = pd.read_sql(sql_query1, sql_engine)
                LOC_rate_temp.columns = [x.upper() for x in LOC_rate_temp.columns]
                LOC_rate_temp = LOC_rate_temp.sort_values([IDNT_TYPE_COLUMN, "DAY_DT"])

                INPUT_DATASET_temp = input_dataset.sort_values([IDNT_TYPE_COLUMN, "DAY_DT"])

                INPUT_DATASET_temp2 = pd.merge(INPUT_DATASET_temp, LOC_rate_temp, on=[IDNT_TYPE_COLUMN, "DAY_DT"],
                                               how='left')
                INPUT_DATASET_temp2['LOCAL_EXCHNG_RATE'] = INPUT_DATASET_temp2['LOCAL_EXCHNG_RATE'].fillna(-1)

                not_null_INPUT_DATASET = INPUT_DATASET_temp2[INPUT_DATASET_temp2['LOCAL_EXCHNG_RATE'] != -1]
                INPUT_DATASET_rej = INPUT_DATASET_temp2[INPUT_DATASET_temp2['LOCAL_EXCHNG_RATE'] == -1]

                if primary2local == "Y":

                    cal_INPUT_DATASET = not_null_INPUT_DATASET.copy()
                    cal_INPUT_DATASET['EXCHNG_RATE'] = cal_INPUT_DATASET['LOCAL_EXCHNG_RATE'] / (prime_exchng_rate)
                    cal_INPUT_DATASET['EXCHNG_RATE'] = cal_INPUT_DATASET['EXCHNG_RATE'].astype(float)

                else:
                    cal_INPUT_DATASET = not_null_INPUT_DATASET.copy()
                    cal_INPUT_DATASET['EXCHNG_RATE'] = (prime_exchng_rate) / cal_INPUT_DATASET['LOCAL_EXCHNG_RATE']
                    cal_INPUT_DATASET['EXCHNG_RATE'] = cal_INPUT_DATASET['EXCHNG_RATE'].astype(float)

                GENERATE_AMT = cal_INPUT_DATASET
                for field in convert_amt_fields:
                    GENERATE_AMT['{}_TMP'.format(field)] = GENERATE_AMT[field] * GENERATE_AMT['EXCHNG_RATE']
                    GENERATE_AMT['{}_TMP'.format(field)] = GENERATE_AMT['{}_TMP'.format(field)].astype(float)

                if primary2local == "Y":

                    for field in convert_amt_fields:
                        GENERATE_AMT.rename(columns={'{}_TMP'.format(field): '{}_LCL'.format(field)}, inplace=True)

                else:

                    for field in convert_amt_fields:
                        GENERATE_AMT.rename(columns={field: '{}_LCL'.format(field)}, inplace=True)
                        GENERATE_AMT.rename(columns={'{}_TMP'.format(field): field}, inplace=True)

                GENERATE_AMT.drop(['LOCAL_EXCHNG_RATE', 'EXCHNG_RATE'], axis=1, inplace=True)

                CONVERT_CURRENCY = GENERATE_AMT.copy()

                CONV_CURR_REJ_FILE = INPUT_DATASET_rej.copy()
                CONV_CURR_REJ_FILE['ERROR_MESSAGE'] = "Unable to convert currency for {}, DAY_DT".format(
                    IDNT_TYPE_COLUMN)
                CONV_CURR_REJ_FILE = CONV_CURR_REJ_FILE[['ERROR_MESSAGE', IDNT_TYPE_COLUMN, 'DAY_DT']]

            else:

                OUTPUT_DATASET = INPUT_DATASET.copy()

                for field in convert_amt_fields:
                    OUTPUT_DATASET['{}_LCL'.format(field)] = np.nan

                CONVERT_CURRENCY = OUTPUT_DATASET.copy()

                CONV_CURR_REJ_FILE = pd.DataFrame(columns=['ERROR_MESSAGE', 'LOC_IDNT', 'DAY_DT'])

        return CONVERT_CURRENCY, CONV_CURR_REJ_FILE


    except Exception as e:

        raise Exception(f"The error is from currency_converter function : {e}")


def add_job_log(job_dict, key, val):
    if key in ["count", "count_rej", "s3_file_location", "job_outcome", "tag"]:
        job_dict[key] = val
    else:
        raise ValueError(f'Not a valid job log key: {key}')
