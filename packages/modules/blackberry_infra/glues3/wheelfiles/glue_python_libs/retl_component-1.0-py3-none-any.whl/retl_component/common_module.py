from awsglue.utils import getResolvedOptions
import sys


def get_job_params(job_params, optional_params=[]):
    """
     Get job parameters at the time of script execution.
    :param job_params: required parameters
    :param optional_params: Optional parameters
    :return: return dictionary with job_param keywords
    """
    try:
        sys_params = [sys_param.split("=")[0].split("--")[-1] for sys_param in sys.argv]

        for param in optional_params:
            if param in sys_params:
                job_params.append(param)

        args = getResolvedOptions(sys.argv, job_params)
    except Exception as e:
        raise ValueError(e)
    return args

