# Initialization the required libraries

import boto3
from botocore.exceptions import ClientError
import gzip
from io import BytesIO, StringIO
import os
from dotenv import load_dotenv
import pandas as pd

load_dotenv()

ENVIRONMENT = os.getenv('ENVIRONMENT', 'prod')
AWS_PROFILE_NAME = os.getenv('AWS_PROFILE_NAME')


class S3:

    def __init__(self, bucket_name):
        self.bucket_name = bucket_name
        self.client = self.__s3_client()

    def __s3_client(self):

        if ENVIRONMENT.lower() == 'local':
            session = boto3.Session(profile_name=AWS_PROFILE_NAME)
            client = session.client('s3')
        else:
            client = boto3.client('s3')
        return client

    def upload_df_s3(self,
                     dataframe,
                     object_key,
                     header_status=False,
                     separator='|',
                     encoding='utf-8',
                     compressed=False,
                     ):
        '''

        :param dataframe: give the dataframe that needs to br uploaded in S3
        :param object_key: give the path along with the file name
         where the dataframe should be uploaded
        :param header_status: is set to 'False' (by default), make it to 'True'
        if you want to include columns from dataframe
        :param separator: is set to '|' (by default),
        give the separator that will delimit the data
        :param encoding: is set to 'utf-8' (by default),
        specify the encoding type
        :param compressed: is set to 'True' (by default), make it 'False'
        so that fataframe is uploaded without compression
        :return: string mentioning the success of upload

        '''

        # converting dataframe to file-like string object (readable)
        csv_buffer_str = StringIO()
        dataframe.to_csv(csv_buffer_str, header=header_status,
                         index=False, sep=separator)

        # converting dataframe to file-like Bytes object (readable)
        csv_buffer_byte = BytesIO()
        csv_buffer_byte = BytesIO(csv_buffer_str.getvalue().encode(encoding))

        if compressed:

            # compressing the Bytes object (non-readable) to gzip
            buf_compress = gzip.compress(csv_buffer_byte.getvalue())

            # creating a new Bytes object (readable)
            # from non-readable Bytes object
            buffer_gzip = BytesIO()
            buffer_gzip = BytesIO(buf_compress)

        else:
            buffer_gzip = csv_buffer_byte

        # Actual code to upload the dataframe transformed file to s3
        try:

            self.client.upload_fileobj(buffer_gzip,
                                       self.bucket_name, object_key)
            return {'status': 0, 'msg': f'File {object_key} Uploaded Successfully'}

        except ClientError as e:
            raise e

    def get_s3_fileobject_name(self, file_path, filename, file_date, file_extension='.txt'):
        """
        This function is used to make fileobject for s3 bucket
        :param file_path:
        :param filename:
        :param file_date:
        :param file_extension:
        :return:
        """

        if file_path[-1] != '/':
            file_path = file_path + '/'
        file_ext = filename.split('.', 1)  # split via first occurrence of "."
        if len(file_ext) > 1:
            s3_file_object = f"{file_path}{file_date}/{file_ext[0]}_" \
                             f"{file_date}.{file_ext[1]}"
        else:
            s3_file_object = f"{file_path}{file_date}/{filename}_" \
                             f"{file_date}{file_extension}"
        return s3_file_object

    def read_file_contents(self, s3_file_path, s3_filename, encoding='utf-8'):
        """
        This function is used to read fileobject from s3 bucket
        :param s3_file_path:
        :param s3_filename:
        :param encoding:
        :return:
        """
        try:
            response = self.client.get_object(
                Bucket=self.bucket_name,
                Key=s3_file_path + s3_filename
            )
            contents = response['Body'].read().decode(encoding)
        except ClientError:
            raise (f"file:{s3_file_path + s3_filename} not found in S3")

        return contents

    def get_df_from_s3object(self, s3_dependency_file_path, delimiter, colnames, gzip_compresed=False, encoding='utf-8'):

        """
        :param s3_dependency_file_path: the path with the dependent file name
        :param delimiter: specify the delimiter used in above mentioned dependency file
        :param colnames: mention the column names the data from dependent file have
        :param gzip_compresed: specify it as True only if the dependent file 'gzip' is compressed
        :param encoding: specify the encoding of the dependent file
        :return: a readily usable dataframe of the file read from s3

        """

        s3_data = self.client.get_object(
            Bucket=self.bucket_name,
            Key=s3_dependency_file_path,
        )

        if gzip_compresed:

            with gzip.GzipFile(fileobj=s3_data["Body"]) as gzipfile:
                contents = gzipfile.read().decode(encoding)

        else:

            contents = s3_data['Body'].read().decode(encoding)

        data_frame = pd.read_csv(
            StringIO(contents),
            delimiter=delimiter,
            header=None,
            names=colnames,
        )

        return data_frame


    def put_object_to_s3(self,json_data, filename):
        """
        Put python object to s3 mainly json data
        :param json_data:
        :param filename:
        :return:
        """

        try:
            self.client.put_object(
                Body=json_data,
                Bucket=self.bucket_name,
                Key=filename)
        except ClientError as e:
            raise ValueError("Unable to upload to s3 bucket:"+str(e))
